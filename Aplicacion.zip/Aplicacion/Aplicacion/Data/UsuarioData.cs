﻿using Aplicacion.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace Aplicacion.Data
{
    public class UsuarioData
    {
        public static bool registrarCliente(Cliente oCliente)
        {
            ConexionBd objEst = new ConexionBd();
            string sentencia;
            sentencia = "EXECUTE USP_GUARDAR_CLI '" + oCliente.IdCliente + "','" + oCliente.Nombre + "','" +oCliente.Apellido 
                + "','" +oCliente.Telefono + "','" +oCliente.Direccion + "','" +oCliente.Email + "','" 
                +oCliente.Usuario + "','" +oCliente.Contrasena +"'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }


        public static bool actualizarCliente(Cliente oCliente)
        {
            ConexionBd objEst = new ConexionBd();
            string sentencia;
            sentencia = "EXECUTE USP_ACTUALIZAR_CLI '" + oCliente.IdCliente + "','" + oCliente.Nombre + "','" + oCliente.Apellido + "','" + oCliente.Telefono + "','" + oCliente.Direccion + "','" + oCliente.Email + "','" + oCliente.Usuario + "','" + oCliente.Contrasena + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }


        public static bool eliminarUsuario(string id)
        {
            ConexionBd objEst = new ConexionBd();
            string sentencia;
            sentencia = "EXECUTE USP_ELIMINAR_CLI '" + id + "'";
            if (!objEst.EjecutarSentencia(sentencia, false))
            {
                objEst = null;
                return false;
            }
            else
            {
                objEst = null;
                return true;
            }
        }



        public static List<Cliente> Listar()
        {
            List<Cliente> oListaCliente = new List<Cliente>();
            ConexionBd objEst = new ConexionBd();
            string sentencia;
            sentencia = "EXECUTE USP_LISTAR_CLI";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaCliente.Add(new Cliente()
                    {
                        IdCliente = Convert.ToInt32(dr["IdCliente"]),
                        Nombre = dr["Nombre"].ToString(),
                        Apellido = dr["Apellido"].ToString(),
                        Telefono = dr["Telefono"].ToString(),
                        Direccion = dr["Direccion"].ToString(),
                        Email = dr["Email"].ToString(),
                        Usuario = dr["Usuario"].ToString(),
                        Contrasena = dr["Contrasena"].ToString()

                    });
                }
                return oListaCliente;
            }
            else
            {
                return oListaCliente;
            }
        }


        public static List<Cliente> Obtener(string id)
        {
            List<Cliente> oListaCliente = new List<Cliente>();
            ConexionBd objEst = new ConexionBd();
            string sentencia;
            sentencia = "EXECUTE  USP_CONSULTAR_CLI'" + id + "'";
            if (objEst.Consultar(sentencia, false))
            {
                SqlDataReader dr = objEst.Reader;
                while (dr.Read())
                {
                    oListaCliente.Add(new Cliente()
                    {
                        IdCliente = Convert.ToInt32(dr["IdCliente"]),
                        Nombre = dr["Nombre"].ToString(),
                        Apellido = dr["Apellido"].ToString(),
                        Telefono = dr["Telefono"].ToString(),
                        Direccion = dr["Direccion"].ToString(),
                        Email = dr["Email"].ToString(),
                        Usuario = dr["Usuario"].ToString(),
                        Contrasena = dr["Contrasena"].ToString()
                    });
                }
                return oListaCliente;
            }
            else
            {
                return oListaCliente;
            }
        }



    }
    }
