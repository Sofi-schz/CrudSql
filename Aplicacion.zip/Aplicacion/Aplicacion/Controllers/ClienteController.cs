﻿using Aplicacion.Data;
using Aplicacion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Aplicacion.Controllers
{
    public class ClienteController : ApiController
    {
        // GET api/<controller>
        public List<Cliente> Get()
        {
            return UsuarioData.Listar;
        }

        // GET api/<controller>/5
        public List <Cliente> Get(String id)
        {
            return UsuarioData.Obtener(id);
        }

        // POST api/<controller>
        public bool Post([FromBody] Cliente oCliente)
        {
            return UsuarioData.registrarCliente(oCliente);
        }

        // PUT api/<controller>/5
        public bool Put( [FromBody] Cliente oCliente)
        {
            return UsuarioData.actualizarCliente(oCliente);
        }

        public bool Patch([FromBody]Cliente oCliente)
        {
            return UsuarioData.actualizarCliente(oCliente);
        }
        // DELETE api/<controller>/5
        public bool Delete(String id)
        {
            return UsuarioData.eliminarUsuario(id);
        }
    }
}