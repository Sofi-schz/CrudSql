﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aplicacion.Models
{
    public class Cliente
    {
        
        private int IdCliente { get; set; }
        private string Nombre { get; set; }
        private string Apellido { get; set; }
        private string Telefono { get; set; }
        private string Direccion { get; set; }
        private string Email { get; set; }
        private string Usuario { get; set; }
        private string Contrasena { get; set; }
    }
}